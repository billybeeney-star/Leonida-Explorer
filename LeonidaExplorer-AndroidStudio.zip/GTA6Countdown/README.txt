LEONIDA EXPLORER - Android project (Version 1)

Includes:
- Full-screen original illustrated Leonida-inspired map concept.
- App title: Leonida Explorer.
- Offline operation; no internet permission and no adverts in this starter build.
- Unofficial fan-project disclaimer.

Build an installable APK:
1. Install Android Studio: https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio choose Open and select the LeonidaExplorer project folder.
4. Allow Gradle sync and install Android SDK Platform 35 if requested.
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

This ZIP is the Android Studio source project, NOT a compiled APK. This environment does not have the Android SDK/Gradle build toolchain installed, so an APK could not be compiled here.

The map is original illustrative artwork, not an official GTA VI map. Before public or monetised distribution, review Rockstar/Take-Two fan-content and trademark rules and consider legal advice.
